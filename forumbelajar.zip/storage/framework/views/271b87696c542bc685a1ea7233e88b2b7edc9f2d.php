<!doctype html>
<html lang="en">
<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
.dots {
    font-style: italic;
    font-size:10pt;
    float:right;
    padding:10px
}
</style>
<body>
    <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br><br>
    <section class="blog_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <div class="blog_left_sidebar">
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $str = strtotime($berita->created_at);
                            $day = date('d',$str);
                            $month = date('M',$str);
                        ?>
                        <article class="blog_item">
                            <div class="blog_item_img">
                                <img class="card-img rounded-0" src="<?php echo e(url('storage/'.$berita->image)); ?>" alt="">
                                <a href="#" class="blog_item_date">
                                    <h3><?=$day?></h3>
                                    <p><?=$month?></p>
                                </a>
                            </div>

                            <div class="blog_details">
                                <a class="d-inline-block" href="single-blog.html">
                                    <h2><?=$berita->headline?></h2>
                                </a>
                                <p><?php if(strlen($berita->content) > 50): ?>
                                        <?=substr($berita->content, 0,100).'...';?>
                                        <a href="<?php echo e(route('homepage.berita.detail',[$berita->slug])); ?>"><span class="dots"> Baca selengkapnya<span></a>
                                    <?php endif; ?></p>
                                <ul class="blog-info-link">
                                    <li><a href="<?php echo e(route('homepage.berita',['category' => $berita->category_id])); ?>"><i class="far fa-user"></i> <?=$berita->category->category_name?></a></li>
                                </ul>
                            </div>
                        </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?=$news->links()?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="blog_right_sidebar">
                        <aside class="single_sidebar_widget post_category_widget">
                            <h4 class="widget_title">Kategori</h4>
                            <ul class="list cat-list">
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('homepage.berita',['category' => $val->id])); ?>" class="d-flex">
                                        <p><?=$val->category_name?></p>
                                        <p>(<?=$val->amount?>)</p>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================Blog Area =================-->

    <!-- footer part start-->
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer part end-->

</body>

</html><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/listberita.blade.php ENDPATH**/ ?>