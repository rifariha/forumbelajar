<?php echo Form::open(['route' => ['news.destroy', $id], 'method' => 'delete']); ?>

<div class='btn-group'>
    <a href="<?php echo e(route('news.show', $id)); ?>" class='btn btn-default btn-sm'>
        <i class="glyphicon glyphicon-eye-open"></i>
    </a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-berita')): ?>
    <a href="<?php echo e(route('news.edit', $id)); ?>" class='btn btn-default btn-sm'>
        <i class="glyphicon glyphicon-edit"></i>
    </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus-berita')): ?>
    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', [
        'type' => 'submit',
        'class' => 'btn btn-danger btn-sm',
        'onclick' => "return confirm('Are you sure?')"
    ]); ?>

    <?php endif; ?>
</div>
<?php echo Form::close(); ?>

<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/news/datatables_actions.blade.php ENDPATH**/ ?>