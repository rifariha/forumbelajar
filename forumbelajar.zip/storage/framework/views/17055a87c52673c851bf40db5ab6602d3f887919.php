<div class="col-md-12">

            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <?php $no = 1;?>
                <?php $__currentLoopData = $topicLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?=$no?>">
                        Pelajaran Ke - <?= $no ?>
                      </a>
                    </h4>
                  </div>
                  <div id="collapse<?=$no?>" class="panel-collapse collapse">
                    <div class="box-body">
                      <?=$lesson->lesson ?>
                    </div>
                        <div class='btn-group' style="display: flex; justify-content: flex-end">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-pelajaran')): ?>
                            <a href="<?php echo e(route('topicLessons.edit', [$topic->chapter->id,$topic->id,$lesson->id])); ?>" class='btn btn-default btn-md'>
                                Edit
                            </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus-pelajaran')): ?>
                            <form action="<?php echo e(route('topicLessons.destroy',[$topic->chapter_id,$topic->id,$lesson->id])); ?>" method="post">
                              <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                              <button class="btn btn-danger btn-md" type="submit">Hapus</button>
                            </form>
                            <?php endif; ?>
                        </div>
                  </div>
                </div>
                <?php $no++;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

          <!-- /.box -->
        </div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/topic_lessons/accordion.blade.php ENDPATH**/ ?>