

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1 class="pull-left">Edit User Profile</h1><br><br>
        <div>
            <?php echo e(Breadcrumbs::render('profile')); ?>

        </div>
        <h1 class="pull-right">
            <a class="btn btn-success pull-right" style="margin-top: -10px;margin-bottom: 5px" data-toggle="modal" data-target="#change-password">Ganti Password</a>
        </h1>
    </section>
    <br>
   <div class="content">
       <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
       <div class="box box-primary">
           <div class="box-body">
               <div class="row">
                  <?php echo Form::model($user, ['route' => ['profile.update'], 'method' => 'patch', 'files' => true,'enctype'=>'multipart/form-data']); ?>


                        <!-- Name Field -->
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('name', 'Nama:', ['class' => 'required']); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

                        </div>

                        <!-- Username Field -->
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('email', 'Email:', ['class' => 'required']); ?>

                            <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

                        </div>

                        <!-- Username Field -->
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('username', 'Username:', ['class' => 'required']); ?>

                            <?php echo Form::text('username', null, ['class' => 'form-control']); ?>

                        </div>

                        <!-- Address Field -->
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('address', 'Alamat:', ['class' => 'required']); ?>

                            <?php echo Form::textarea('address', null, ['class' => 'form-control', 'rows'=>2]); ?>

                        </div>

                        <!-- Phone Field -->
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('phone', 'No. Telepon:', ['class' => 'required']); ?>

                            <?php echo Form::number('phone', null, ['class' => 'form-control']); ?>

                        </div>
                        <!-- Phone Field -->
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('image', 'Ganti Foto Profil:', ['class' => 'required']); ?>

                            <?php echo Form::file('image', null, ['class' => 'form-control']); ?>

                        </div>

                        <div class="col-md-12"><br></div>
                        <div class="form-group col-sm-4">
                            <?php echo Form::label('password', 'Password:', ['class' => 'required']); ?>

                            <?php echo Form::password('password', ['class' => 'form-control']); ?>

                        </div>

                        <!-- Submit Field -->
                        <div class="form-group col-sm-12">
                            <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Cancel</a>
                        </div>


                    <?php echo Form::close(); ?>

               </div>
           </div>
       </div>
   </div>

   <div class="modal fade" id="change-password">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Ganti Password</h4>
            </div>
            <div class="modal-body">
                 <?php echo Form::open(['route' => ['profile.changepassword'], 'method' => 'patch' ]); ?>

                <div class="form-group col-sm-12">
                    <?php echo Form::label('password', 'Password Lama:', ['class' => 'required']); ?>

                    <?php echo Form::password('oldpassword', ['class' => 'form-control']); ?>

                </div>

                <div class="form-group col-sm-12">
                    <?php echo Form::label('password', 'Password Baru:', ['class' => 'required']); ?>

                    <?php echo Form::password('password', ['class' => 'form-control']); ?>

                </div>

                <div class="form-group col-sm-12">
                    <?php echo Form::label('password', 'Ulangi Password Baru:', ['class' => 'required']); ?>

                    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

                </div>

            </div>
            <div class="modal-footer">
                
                <div class="form-group col-sm-12">
                    <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                </div>
                
            </div>
            <?php echo Form::close(); ?>

        </div>
        <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/users/profile.blade.php ENDPATH**/ ?>