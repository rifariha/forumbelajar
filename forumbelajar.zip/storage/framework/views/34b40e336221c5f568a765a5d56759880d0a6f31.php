<!-- DataTable Bootstrap -->
<link href="//cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.bootstrap.min.css"><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/layouts/datatables_css.blade.php ENDPATH**/ ?>