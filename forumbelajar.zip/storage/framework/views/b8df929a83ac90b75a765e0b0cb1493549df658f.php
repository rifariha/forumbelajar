<!-- Cms Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('cms_name', 'Nama CMS:', ['class' => 'required']); ?>

    <?php echo Form::text('cms_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Cms Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('type', 'Tipe input:', ['class' => 'required']); ?>

    <?php echo Form::select('type', ['text' => 'Text', 'file' => 'File'], 'text', ['id' => 'select-type','class' => 'form-control']); ?>

</div>

<!-- Content Field -->
<div class="form-group col-sm-12 col-lg-12" id="inputtext">
    <?php echo Form::label('content', 'Content:', ['class' => 'required']); ?>

    <?php echo Form::textarea('content', null, ['id' => 'value' ,'class' => 'form-control']); ?>

</div>

<div class="form-group col-sm-12 col-lg-12" id="inputfile" style="display:none">
    <?php echo Form::label('content', 'Content:', ['class' => 'required']); ?>

    <?php echo Form::file('content', null, ['id' => 'value2','class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('cms.index')); ?>" class="btn btn-default">Cancel</a>
</div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/cms/fields.blade.php ENDPATH**/ ?>