

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1 class="pull-left">Komentar Diskusi Terbaru</h1><br><br>
        <div>
            <?php echo e(Breadcrumbs::render('forum')); ?>

        </div>
    </section>
    <div class="content">
        <div class="clearfix"></div>

        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                    <?php echo $__env->make('forums.timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <center>
                    <?php echo e($forums->links()); ?>

                    </center>
            </div>
        </div>
        <div class="text-center">
        
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/forums/index.blade.php ENDPATH**/ ?>