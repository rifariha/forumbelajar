<!-- Headline Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('headline', 'Judul Berita:', ['class' => 'required']); ?>

    <?php echo Form::text('headline', null, ['class' => 'form-control']); ?>

</div>

<!-- Content Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('content', 'Isi Berita:', ['class' => 'required']); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control ckeditor']); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('image', 'Gambar:', ['class' => 'required']); ?>

    <?php echo Form::file('image', null, ['class' => 'form-control']); ?>

    <i class="red"> Maksimal 1 Mb </i>
    <br>
</div>

<!-- Category Id Field -->
<div class="form-group col-sm-3">
    <?php echo Form::label('category_id', 'Kategori:', ['class' => 'required']); ?>

    <?php echo Form::select('category_id', $category , null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('news.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/news/fields.blade.php ENDPATH**/ ?>