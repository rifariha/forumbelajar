<ul class="timeline">

    <!-- timeline time label -->
    <li class="time-label">
        <span class="bg-info">
           Log Aktivitas
        </span>
    </li>
    <!-- /.timeline-label -->

    <!-- timeline item -->
    <?php $__currentLoopData = $forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <!-- timeline icon -->
        <i class="fa fa-comments bg-blue"></i>
        <div class="timeline-item">
            <span class="time"><i class="fa fa-clock-o"></i> <?= time_since($forum->created_at) ?></span>

            <h3 class="timeline-header"><?php echo e(ucwords($forum->user->name)); ?></h3>

            <div class="timeline-body">
                Telah Berkomentar pada materi <b> <?php echo e($forum->topic->topic_name); ?> </b> : <br>
                <i><?=$forum->comment?></i> 
            </div>

            <div class="timeline-footer">
               <a href="<?php echo e(route('topics.show', [$forum->topic->chapter->id,$forum->topic->id])); ?>" class='btn btn-primary btn-sm'>Lihat Materi Diskusi</a>
            </div>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END timeline item -->


</ul><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/forums/timeline.blade.php ENDPATH**/ ?>