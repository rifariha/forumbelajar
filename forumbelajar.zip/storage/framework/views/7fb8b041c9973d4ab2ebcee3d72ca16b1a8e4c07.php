

<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Isi Pesan
        </h1>
    </section>
    <div class="content">
        <div>
            <?php echo e(Breadcrumbs::render('pesan')); ?>

        </div>
        <div class="box box-primary">
            <div class="box-body">
                <div class="row" style="padding-left: 20px">
                    <a href="<?php echo e(route('messages.index')); ?>" class="btn btn-default">Back</a><br>
                    <div class="col-md-12">
                        <!-- /.box-header -->
                        <div class="box-body no-padding">
                        <div class="mailbox-read-info">
                            <h3><?php echo e($sent->subject); ?></h3>
                            <h5>From: <?php echo e($sent->sender_name); ?>

                            <span class="mailbox-read-time pull-right"> <?php echo e(time_since($sent->created_at)); ?></span></h5>
                        </div>
                    
                        <!-- /.mailbox-controls -->
                        <div class="mailbox-read-message">
                            <?= $sent->message ?>
                        </div>
                        <!-- /.mailbox-read-message -->
                        </div>
                        <!-- /.box-body -->
                        <!-- /.box-footer -->
                        <div class="box-footer">
                        <div class="pull-right">
                        </div>
                        <?php echo Form::open(['route' => ['messages.resend', $sent->batch], 'method' => 'post']); ?>


                        <?php echo Form::button('<i class="fa fa-send"></i> Kirim Ulang', [
                            'type' => 'submit',
                            'class' => 'btn btn-success',
                            'onclick' => "return confirm('Anda yakin mengirim ulang pesan ini ke seluruh user ?')"
                        ]); ?>

                        
                    </div>


                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <!-- /. box -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/messages/sent-item-show.blade.php ENDPATH**/ ?>