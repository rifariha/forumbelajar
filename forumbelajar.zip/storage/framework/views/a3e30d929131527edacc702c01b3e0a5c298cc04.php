<?php $chapter_id = request()->segment(2); ?>
<?php echo Form::open(['route' => ['topics.destroy', $chapter_id,$id], 'method' => 'delete']); ?>

<div class='btn-group'>
    <a href="<?php echo e(route('topics.show', [$chapter_id,$id])); ?>" class='btn btn-primary btn-md'>
        Lihat Materi
    </a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-materi')): ?>
    <a href="<?php echo e(route('topics.edit', [$chapter_id,$id])); ?>" class='btn btn-default btn-md'>
        <i class="glyphicon glyphicon-edit"></i>
    </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hapus-materi')): ?>
    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', [
        'type' => 'submit',
        'class' => 'btn btn-danger btn-md',
        'onclick' => "return confirm('Are you sure?')"
    ]); ?>

    <?php endif; ?>
</div>
<?php echo Form::close(); ?>

<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/datatables_actions.blade.php ENDPATH**/ ?>