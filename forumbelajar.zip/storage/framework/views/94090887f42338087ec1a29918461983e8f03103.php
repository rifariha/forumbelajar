<li class="<?php echo e(Request::is('chapters*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('chapters.index')); ?>"><i class="fa fa-book"></i><span>Bab & Materi</span></a>
</li>

<li class="<?php echo e(Request::is('messages*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('messages.index')); ?>"><i class="fa fa-envelope"></i><span>Kelola Pesan <span class="pull-right-container">
        <?php if($read != 0): ?>
              <span class="label label-danger pull-right"><?=$read?>
            </span> 
        <?php endif; ?>
        </a>
</li>

<li class="<?php echo e(Request::is('forums*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('forums.index')); ?>"><i class="fa fa-comments-o"></i><span>Forum Diskusi</span></a>
</li>

<?php if(auth()->check() && auth()->user()->hasAnyRole('Superadmin|Admin')): ?>
<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-users"></i><span>Users</span></a>
</li>

<li class="treeview <?php echo e(Request::is('news*') ? 'active menu-open' : ''); ?>">
    <a href="#">
    <i class="fa fa-newspaper-o"></i><span>Berita</span>
    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
    <ul class="treeview-menu">
        <li class="<?php echo e(Request::is('news') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('news.index')); ?>"><i class="fa fa-reorder"></i><span>Daftar Berita</span></a>
        </li>
        <li class="<?php echo e(Request::is('newsCategories*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('newsCategories.index')); ?>"><i class="fa fa-map-signs"></i><span>Kategori Berita</span></a>
        </li>
    </ul>
</li>

<li class="<?php echo e(Request::is('galleries*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('galleries.index')); ?>"><i class="fa fa-camera"></i><span>Dokumentasi</span></a>
</li>

<li class="<?php echo e(Request::is('testimonials*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('testimonials.index')); ?>"><i class="fa fa-sliders"></i><span>Testimonials</span></a>
</li>

<li class="<?php echo e(Request::is('cms*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('cms.index')); ?>"><i class="fa fa-gears"></i><span>Cms</span></a>
</li>

<li class="<?php echo e(Request::is('backupLogs*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('backupLogs.index')); ?>"><i class="fa fa-database"></i><span>Log Backup</span></a>
</li>

<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
<li class="<?php echo e(Request::is('permissions*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('permissions.index')); ?>"><i class="fa fa-unlock"></i><span>Permissions</span></a>
</li>
<li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-smile-o"></i><span>Roles</span></a>
</li>
<?php endif; ?>

<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/layouts/menu.blade.php ENDPATH**/ ?>