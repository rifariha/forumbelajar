

<?php $__env->startSection('content'); ?>
    <section class="content-header">
    <h1 class="pull-left">Materi <?php echo e($chapter->chapter_name); ?></h1><br><br>
     <p align="justify"> <?php echo e($chapter->description); ?> </p>
    <br>
        <div>
            <?php echo e(Breadcrumbs::render('materi',$chapter)); ?>

        </div>
        <h1 class="pull-right">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tambah-materi')): ?>
            <?php $chapter_id = request()->segment(2); ?>
           <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="<?php echo e(route('topics.create',[$chapter_id])); ?>">Tambah Materi Bab</a>
            <?php endif; ?>
        </h1>
    </section>
    <div class="content">
        <div class="clearfix"></div>

        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                    <?php echo $__env->make('chapters.topics.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="text-center">
        
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/index.blade.php ENDPATH**/ ?>