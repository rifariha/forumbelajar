<!-- Headline Field -->
<div class="form-group">
    <?php echo Form::label('headline', 'Judul Berita:'); ?>

    <p><?php echo e($news->headline); ?></p>
</div>

<!-- Created By Field -->
<div class="form-group">
    <?php echo Form::label('created_by', 'Dibuat Oleh:'); ?>

    <p><?php echo e($news->created_by); ?></p>
</div>

<!-- Category Id Field -->
<div class="form-group">
    <?php echo Form::label('category_id', 'Kategori:'); ?>

    <p><?php echo e($news->category->category_name); ?></p>
</div>

<!-- Content Field -->
<div class="form-group">
    <?php echo Form::label('content', 'Isi Berita:'); ?>

    <p><?=$news->content ?></p>
</div>

<!-- Image Field -->
<div class="form-group">
    <?php echo Form::label('image', 'Gambar:'); ?><br>
    <img src="<?php echo e(url('storage/'.$news->image)); ?>" width="20%">
</div>


<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/news/show_fields.blade.php ENDPATH**/ ?>