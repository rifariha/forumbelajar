<!-- Short Description Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('short_description', 'Judul:', ['class' => 'required']); ?>

    <?php echo Form::text('short_description', null, ['class' => 'form-control']); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('description', 'Deskripsi:', ['class' => 'required']); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

</div>

<!-- Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image', 'Foto:', ['class' => 'required']); ?>

    <?php echo Form::file('image', null, ['class' => 'form-control']); ?>

    <i class="red"> Maksimal 1 Mb </i>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('galleries.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/galleries/fields.blade.php ENDPATH**/ ?>