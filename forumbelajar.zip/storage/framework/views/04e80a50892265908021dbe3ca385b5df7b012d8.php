<!-- Cms Name Field -->
<?php if(auth()->check() && auth()->user()->hasRole('Superadmin')): ?>
<div class="form-group col-sm-12">
    <?php echo Form::label('cms_name', 'Nama CMS:', ['class' => 'required']); ?>

    <?php echo Form::text('cms_name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group col-sm-12">
    <?php echo Form::label('type', 'Tipe Input:'); ?>

    <?php echo Form::select('type', ['text' => 'Text', 'file' => 'File'], null, ['class' => 'form-control']); ?>

</div>

<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
<div class="form-group col-sm-12">
    <?php echo Form::label('cms_name', 'Nama CMS:', ['class' => 'required']); ?>

    <?php echo Form::text('cms_name', null, ['class' => 'form-control','readonly']); ?>

</div>
<?php endif; ?>

<?php if($cms->type == 'text'): ?>
<!-- Content Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('content', 'Content:', ['class' => 'required']); ?>

    <?php echo Form::textarea('content', null, ['class' => 'form-control']); ?>

</div>
<?php elseif($cms->type == 'file'): ?>
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('content', 'Content:', ['class' => 'required']); ?>

    <?php echo Form::file('content', null, ['class' => 'form-control']); ?>

</div>
<?php endif; ?>
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('cms.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/cms/edit-fields.blade.php ENDPATH**/ ?>