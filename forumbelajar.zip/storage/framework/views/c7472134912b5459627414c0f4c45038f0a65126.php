
    <!-- jquery plugins here-->
    <!-- jquery -->
    <script src="<?php echo e(asset('template/js/jquery-1.12.1.min.js')); ?>"></script>
    <!-- popper js -->
    <script src="<?php echo e(asset('template/js/popper.min.js')); ?>"></script>
    <!-- bootstrap js -->
    <script src="<?php echo e(asset('template/js/bootstrap.min.js')); ?>"></script>
    <!-- easing js -->
    <script src="<?php echo e(asset('template/js/jquery.magnific-popup.js')); ?>"></script>
    <!-- swiper js -->
    <script src="<?php echo e(asset('template/js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.nice-select.min.js')); ?>"></script>
    <!-- swiper js -->
    <script src="<?php echo e(asset('template/js/masonry.pkgd.js')); ?>"></script>
    <!-- particles js -->
    <script src="<?php echo e(asset('template/js/owl.carousel.min.js')); ?>"></script>
    <!-- swiper js -->
    <script src="<?php echo e(asset('template/js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/waypoints.min.js')); ?>"></script>
    <!-- custom js -->
    <script src="<?php echo e(asset('template/js/custom.js')); ?>"></script><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/js.blade.php ENDPATH**/ ?>