<!-- Lesson Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('lesson', 'Isi Pelajaran:'); ?>

    <?php echo Form::textarea('lesson', null, ['class' => 'form-control ckeditor']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('topics.show',[$topic->chapter_id,$topic->id])); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/topic_lessons/fields.blade.php ENDPATH**/ ?>