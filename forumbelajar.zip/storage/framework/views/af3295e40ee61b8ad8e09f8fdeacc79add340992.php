<div class="box-header with-border">

    <div class="box-tools pull-right">
    <div class="has-feedback">
        
        
    </div>
    </div>
    <!-- /.box-tools -->
</div>
<!-- /.box-header -->
<div class="box-body no-padding">

    <div class="table-responsive mailbox-messages">
    <table class="table table-hover table-striped">
        <tbody>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
        <tr>
        <td></td>
        <td class="mailbox-name"><a href="<?php echo e(route('messages.show', [$message->id])); ?>">Dari : <?php echo e($message->sender_name); ?></a></td>
        <td class="mailbox-subject <?php if($message->status == 0) { echo 'textbold'; }?>"><?php echo e($message->subject); ?> - <?=limit_word($message->message,5)?> ..
        </td>
    <td class="mailbox-date"><?php echo e(time_since($message->created_at)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!-- /.table -->
    </div>
    <!-- /.mail-box-messages -->
</div>
<!-- /.box-body -->
<div class="box-footer no-padding">
    <div class="mailbox-controls"  style="display: flex; justify-content: flex-end">
    <!-- Check all button -->
    <?php echo e($messages->links()); ?>

    </div>
</div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/messages/inbox.blade.php ENDPATH**/ ?>