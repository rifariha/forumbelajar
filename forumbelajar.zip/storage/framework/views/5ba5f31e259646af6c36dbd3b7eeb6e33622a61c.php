<!-- Slider Name Field -->
<div class="form-group">
    <?php echo Form::label('slider_name', 'Judul Slider:'); ?>

    <p><?php echo e($slider->slider_name); ?></p>
</div>


<!-- Desription Field -->
<div class="form-group">
    <?php echo Form::label('desription', 'Deskripsi:'); ?>

    <p><?php echo e($slider->desription); ?></p>
</div>

<!-- Image Field -->
<div class="form-group">
    <?php echo Form::label('image', 'Foto:'); ?>

   <img src="<?php echo e(url('storage/'.$slider->image)); ?>" width="20%">
</div>


<?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/testimonials/show_fields.blade.php ENDPATH**/ ?>