<h2> Backup Diskusi Materi <?=$topic->topic_name?></h2>

<div class="col-md-12">
<hr>
    <!-- Post -->
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post clearfix">
        <div class="user-block">
            <span class="username">
                <a href="#"><?=ucwords($comment->user->name)?></a>
            </span>
        <span class="description">
            <?php echo e($comment->created_at); ?>

        </span>
        </div>
      
        <!-- /.user-block -->
        <p> <?= $comment->comment ?></p>
        <?php $__currentLoopData = $comment->descendant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<div class="user-block" style="margin-left: 4rem">
                    <span class="username">
                        <a href="#"><?=ucwords($reply->user->name)?></a>
                    </span>
                <span class="description">
                    <?php echo e($reply->created_at); ?>

                </span>
                <p style="padding-top:5pt"><?=$reply->comment?></p>
                
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
</div>

<div class="col-md-12"><br></div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/topic_lessons/discussion_backup.blade.php ENDPATH**/ ?>