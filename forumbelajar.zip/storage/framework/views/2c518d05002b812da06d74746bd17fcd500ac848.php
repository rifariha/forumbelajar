

<?php $__env->startSection('content'); ?>
<style>
    .textbold{
        font-weight: bold;
    }
</style>
    <section class="content-header">
        <h1 class="pull-left">Kelola Pesan</h1><br><br>
        <div>
            <?php echo e(Breadcrumbs::render('pesan')); ?>

        </div>
         <h1 class="pull-right">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kirim-pesan')): ?>
           <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="<?php echo e(route('messages.create')); ?>"><i class="fa fa-pencil"></i> Broadcast Pesan</a>
            <?php endif; ?>
        </h1>
    </section>
    <div class="content">
        <div class="clearfix"></div>

        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>

          <!-- Custom Tabs -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <?php if(!auth()->check() || ! auth()->user()->hasRole('Superadmin|Admin')): ?>
              <li class="<?php if(!Auth::user()->hasRole('Admin')){echo 'active';}?>"><a href="#inbox" data-toggle="tab"><i class="fa fa-inbox"> Kotak Masuk </i></a></li>
              <?php endif; ?>
              <?php if(auth()->check() && auth()->user()->hasAnyRole('Superadmin|Admin')): ?>
              <li class="<?php if(Auth::user()->hasRole('Admin')||Auth::user()->hasRole('Superadmin')){echo 'active';}?>"><a href="#sent" data-toggle="tab"><i class="fa fa-envelope"> Pesan Terkirim </i></a></li>
              <?php endif; ?>
            </ul>
            <div class="tab-content">
              <?php if(!auth()->check() || ! auth()->user()->hasRole('Superadmin|Admin')): ?>
              <div class="tab-pane <?php if(!Auth::user()->hasRole('Admin')){echo 'active';}?>" id="inbox">
                <?php 
                $temps = $messages->toArray();
                if(empty($temps['data'])) { echo "Anda belum mengirim pesan apapun";}?>
                <?php echo $__env->make('messages.inbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
              <?php endif; ?>
              <?php if(auth()->check() && auth()->user()->hasAnyRole('Superadmin|Admin')): ?>
              <div class="tab-pane <?php if(Auth::user()->hasRole('Admin')||Auth::user()->hasRole('Superadmin')){echo 'active';}?>" id="sent">
                <?php 
                $temp = $sents->toArray();
                if(empty($temp['data'])) { echo "Anda belum mengirim pesan apapun";}?>
                 <?php echo $__env->make('messages.sent-item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
             <?php endif; ?>
            </div>
            <!-- /.tab-content -->
          </div>
  
        
        <div class="text-center">
        
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/messages/index.blade.php ENDPATH**/ ?>