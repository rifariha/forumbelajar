<script src="//cdn.ckeditor.com/4.14.1/basic/ckeditor.js"></script>

<div class="col-md-12">
<h3> Ranah Diskusi </h3>
<?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<hr>
    <!-- Post -->
    <?php  $temp = $comments->toArray(); if(empty($temp['data'])) { echo "Belum ada diskusi di materi pelajaran ini";}?>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post clearfix">
        <div class="user-block">
        <img class="img-circle img-bordered-sm" src="<?php echo e(url('storage/'.$comment->user->image)); ?>" alt="User Image">
            <span class="username">
                <a href="#"><?=ucwords($comment->user->name)?></a>
            </span>
        <span class="description">
            <?php echo e(time_since($comment->created_at)); ?>

        </span>
        </div>
        <?php if(Auth::user()->hasRole('Superadmin') || Auth::user()->hasRole('Admin') || Auth::user()->id == $comment->user_id): ?>
            <?php echo $__env->make('chapters.topics.topic_lessons.delete_discussion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <!-- /.user-block -->
        <p> <?= $comment->comment ?></p>
        <?php $__currentLoopData = $comment->descendant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<div class="user-block" style="margin-left: 4rem">
                <img class="img-circle img-bordered-sm" src="<?php echo e(url('storage/'.$reply->user->image)); ?>" alt="User Image">
                    <span class="username">
                        <a href="#"><?=ucwords($reply->user->name)?></a>
                    </span>
                <span class="description">
                    <?php echo e(time_since($reply->created_at)); ?>

                </span>
                <p style="padding-top:5pt"><?=$reply->comment?></p>
                <?php if(Auth::user()->hasRole('Superadmin') || Auth::user()->hasRole('Admin') || Auth::user()->id == $reply->user_id): ?>
                     <?php echo $__env->make('chapters.topics.topic_lessons.delete_comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <form class="form-horizontal" method="post" action="<?php echo e(route('forums.store', [$topic->chapter_id,$topic->id])); ?>">
        <div class="form-group margin-bottom-none">
            <div class="col-sm-11">
                <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
                <input name="parent_id" type="hidden" value="<?php echo e($comment->id); ?>"/>
            <textarea class="form-control input-sm" name="comment" placeholder="Jawab" cols=10 rows=3 style="resize: none;"></textarea>
            </div>
            <div class="col-sm-1">
            <button type="submit" class="btn btn-danger pull-right btn-block btn-sm">Balas</button>
            </div>
        </div>
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <center>
    <?php echo e($comments->links()); ?>

    </center>
    <hr>
</div>

<div class="col-md-12"><br></div>
<div class="col-md-12">
    <div class="box-body">
        <?php echo Form::open(['route' => ['forums.store',$topic->chapter_id,$topic->id]]); ?>


       <div class="form-group col-sm-12">
        <?php echo Form::label('comment', 'Buat Diskusi Baru:'); ?>

        <?php echo Form::textarea('comment', null, ['class' => 'form-control ckeditor','rows' => 2, 'cols' => 2]); ?>

        </div>

        <!-- Submit Field -->
        <div class="form-group col-sm-12">
        <?php echo Form::submit('Submit', ['class' => 'btn btn-primary']); ?>

        </div>


        <?php echo Form::close(); ?>

    </div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/topic_lessons/discussion.blade.php ENDPATH**/ ?>