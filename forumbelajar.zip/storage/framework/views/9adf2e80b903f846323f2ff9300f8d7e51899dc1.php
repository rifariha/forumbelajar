

<?php $__env->startSection('content'); ?>
<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <section class="content-header">
        <h1>
            Edit Pelajaran
        </h1>
   </section>
   <div class="content">
        <div>
            <?php echo e(Breadcrumbs::render('lesson',$topic)); ?>

        </div>
       <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <div class="box box-primary">
           <div class="box-body">
               <div class="row">
                   <?php echo Form::model($topicLesson, ['route' => ['topicLessons.update', $topic->chapter_id,$topic->id,$topicLesson->id], 'method' => 'patch']); ?>


                        <?php echo $__env->make('chapters.topics.topic_lessons.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                   <?php echo Form::close(); ?>

               </div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/topic_lessons/edit.blade.php ENDPATH**/ ?>