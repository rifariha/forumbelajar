<!doctype html>
<?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--::review_part start::-->
    <section class="special_cource padding_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-5">
                    <div class="section_tittle text-center">
                        <p>Dokumentasi</p>
                        <h2>Galeri Madrasah</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-4">
                    <div class="single_special_cource">
                    <img src="<?php echo e(url('storage/'.$val->image)); ?>" class="special_img" alt="">
                        <div class="special_cource_text">         
                            <p><?=$val->description?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <br>
    <br>
    <br>
    <br>
    <!--::blog_part end::-->
    <!-- footer part start-->
   <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/documentation.blade.php ENDPATH**/ ?>