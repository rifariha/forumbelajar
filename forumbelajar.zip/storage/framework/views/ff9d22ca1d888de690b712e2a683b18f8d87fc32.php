
<div class="pull-right">
    <form action="<?php echo e(route('forums.destroy',[$topic->chapter_id,$topic->id,$reply->id])); ?>" method="POST">
        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
        <button onclick="return confirm('Hapus Komentar ?')" class="btn btn-danger btn-xs" type="submit"><i class="fa fa-trash"> </i></button>
    </form>
</div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/chapters/topics/topic_lessons/delete_comment.blade.php ENDPATH**/ ?>