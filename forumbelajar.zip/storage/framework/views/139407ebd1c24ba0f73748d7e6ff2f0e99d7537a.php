<footer class="footer-area" id="kontak-kami">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-md-6">
                    <div class="single-footer-widget footer_1">
                        <a href="index.html"> <img src="<?php echo e(url('storage/'.$cms["logo-up-down"])); ?>"  alt=""> </a>
                        <p><?=$cms['footer-description']?></p>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="single-footer-widget footer_2">
                        <h4>Kontak Kami</h4>
                        <div class="contact_info">
                            <p><span> Alamat :</span> <?=$cms['alamat']?> </p>
                            <p><span> Telepon :</span> <?=$cms['telepon']?></p>
                            <p><span> Email : </span><?=$cms['email']?> </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright_part_text text-center">
                        <div class="row">
                            <div class="col-lg-12">
                                <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/footer.blade.php ENDPATH**/ ?>