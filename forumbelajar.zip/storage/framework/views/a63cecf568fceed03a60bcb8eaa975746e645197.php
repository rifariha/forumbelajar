
<!-- /.box-header -->
<div class="box-body no-padding">
    <div class="table-responsive mailbox-messages">
        
    <table class="table table-hover table-striped">
        <tbody>
        <?php $__currentLoopData = $sents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
        <tr>
        <td></td>
        <td class="mailbox-name"><a href="<?php echo e(route('sentitem.show', [$sent->batch])); ?>">Kepada : Semua user</a></td>
        <td class="mailbox-subject"><?php echo e($sent->subject); ?> - <?=limit_word($sent->message,5)?> ..
        </td>
    <td class="mailbox-date"><?php echo e(time_since($sent->created_at)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <!-- /.table -->
    </div>
    <!-- /.mail-box-messages -->
</div>
<!-- /.box-body -->
<div class="box-footer no-padding">
    <div class="mailbox-controls"  style="display: flex; justify-content: flex-end">
    <!-- Check all button -->
    <?php echo e($sents->links()); ?>

    </div>
</div><?php /**PATH D:\Learn\Laravel\forumbelajar3\forumbelajar\resources\views/messages/sent-item.blade.php ENDPATH**/ ?>