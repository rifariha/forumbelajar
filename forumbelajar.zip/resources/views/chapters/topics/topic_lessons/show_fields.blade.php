<!-- Topic Id Field -->
<div class="form-group">
    {!! Form::label('topic_id', 'Topic Id:') !!}
    <p>{{ $topicLesson->topic_id }}</p>
</div>

<!-- Lesson Field -->
<div class="form-group">
    {!! Form::label('lesson', 'Lesson:') !!}
    <p>{{ $topicLesson->lesson }}</p>
</div>

