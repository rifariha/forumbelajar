<div class='btn-group'>
    <a href="{{ route('backupLogs.download', $id) }}" class='btn btn-success btn-md'>
        Download
    </a>
</div>
