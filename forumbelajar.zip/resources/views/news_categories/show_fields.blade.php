<!-- Category Name Field -->
<div class="form-group">
    {!! Form::label('category_name', 'Category Name:') !!}
    <p>{{ $newsCategory->category_name }}</p>
</div>

