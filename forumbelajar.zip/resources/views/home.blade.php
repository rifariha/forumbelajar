@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        
        
        {{-- <div class="col-md-12">
        <iframe src="https://view.officeapps.live.com/op/embed.aspx?src=http%3A%2F%2Fpengacaraterbaik%2Ecom%3A80%2Fassets%2FWARNINGS%2Eppt&amp;wdAr=1.3333333333333333" width="1026px" height="793px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
        </div> --}}
        
    
    </div>
</div>
@endsection
