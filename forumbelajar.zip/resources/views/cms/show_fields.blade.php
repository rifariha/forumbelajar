<!-- Cms Name Field -->
<div class="form-group">
    {!! Form::label('cms_name', 'Cms Name:') !!}
    <p>{{ $cms->cms_name }}</p>
</div>

<!-- Content Field -->
<div class="form-group">
    {!! Form::label('content', 'Content:') !!}
    <p>{{ $cms->content }}</p>
</div>

